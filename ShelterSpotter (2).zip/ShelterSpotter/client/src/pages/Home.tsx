import { useState, useEffect, useCallback, useRef } from 'react';
import Header from '@/components/Header';
import FilterPanel from '@/components/FilterPanel';
import ShelterMap from '@/components/ShelterMap';
import MobileFilterPanel from '@/components/MobileFilterPanel';
import { Shelter } from '@/types/shelter';
import { shelterData } from '@/data/shelterData';
import { getShelterOccupancyService } from '@/services/shelterOccupancyService';

export default function Home() {
  console.log("Home component rendering");
  
  // Shelter data state
  const [shelters, setShelters] = useState<Shelter[]>(shelterData);
  const [filteredShelters, setFilteredShelters] = useState<Shelter[]>(shelterData);
  const [selectedShelter, setSelectedShelter] = useState<Shelter | null>(null);
  
  // User interface state
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [showMobileFilter, setShowMobileFilter] = useState(false);
  const [routeInfo, setRouteInfo] = useState<{distance: string, duration: string} | null>(null);
  
  // Filter options
  const [filterOptions, setFilterOptions] = useState({
    foodAvailable: false,
    spaceAvailable: false,
    occupancyLevel: 'all' as 'all' | 'low' | 'medium' | 'high' | 'full'
  });
  
  // Track cleanup function for occupancy service subscription
  const occupancyUnsubscribeRef = useRef<(() => void) | null>(null);

  // Calculate distance between two points in km (using Haversine formula)
  const calculateDistance = useCallback((
    lat1: number, 
    lon1: number, 
    lat2: number, 
    lon2: number
  ): number => {
    const R = 6371; // Radius of the earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;  
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    return R * c; // Distance in km
  }, []);

  // Find the nearest shelter to a given location
  const findNearestShelter = useCallback((
    location: [number, number], 
    shelterList: Shelter[]
  ): Shelter | null => {
    if (!shelterList || shelterList.length === 0) {
      return null; // Return null if list is empty
    }
    
    let nearestShelter = shelterList[0];
    let shortestDistance = calculateDistance(
      location[0], location[1], 
      nearestShelter.latitude, nearestShelter.longitude
    );
    
    for (let i = 1; i < shelterList.length; i++) {
      const shelter = shelterList[i];
      const distance = calculateDistance(
        location[0], location[1], 
        shelter.latitude, shelter.longitude
      );
      
      if (distance < shortestDistance) {
        shortestDistance = distance;
        nearestShelter = shelter;
      }
    }
    
    return nearestShelter;
  }, [calculateDistance]);

  // Find and select the nearest shelter when user location is available
  const selectNearestShelter = useCallback((userCoords: [number, number]) => {
    // Use filtered shelters if any, otherwise use all shelters
    const availableShelters = filteredShelters.length > 0 
      ? filteredShelters 
      : shelters;
    
    if (availableShelters.length > 0) {
      const nearest = findNearestShelter(userCoords, availableShelters);
      if (nearest) {
        console.log("Found nearest shelter:", nearest.name);
        // Only set if it's different to avoid unnecessary re-renders
        setSelectedShelter(prev => {
          if (!prev || prev.id !== nearest.id) {
            return nearest;
          }
          return prev;
        });
      }
    }
  }, [findNearestShelter, filteredShelters, shelters]);

  // Get current user location
  const getCurrentLocation = useCallback(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userCoords: [number, number] = [
            position.coords.latitude, 
            position.coords.longitude
          ];
          setUserLocation(userCoords);
          selectNearestShelter(userCoords);
        },
        (error) => {
          console.error("Error getting user location:", error);
        }
      );
    }
  }, [selectNearestShelter]);

  // Get user's location and select nearest shelter on initial load
  useEffect(() => {
    getCurrentLocation();
    
    // Poll for location updates
    const locationInterval = setInterval(getCurrentLocation, 10000);
    
    return () => clearInterval(locationInterval);
  }, []);

  // Select nearest shelter when user location changes
  useEffect(() => {
    if (userLocation) {
      selectNearestShelter(userLocation);
    }
  }, [userLocation, selectNearestShelter]);

  // Initialize real-time occupancy service
  useEffect(() => {
    // Initialize service with the initial shelter data
    const occupancyService = getShelterOccupancyService(shelterData);
    
    // Subscribe to real-time updates
    const unsubscribe = occupancyService.subscribe((updatedShelters) => {
      console.log("Received shelter occupancy update");
      setShelters(updatedShelters);
      
      // If we have a selected shelter, update its data
      if (selectedShelter) {
        const updatedSelectedShelter = updatedShelters.find(s => s.id === selectedShelter.id);
        if (updatedSelectedShelter && 
            updatedSelectedShelter.currentOccupancy !== selectedShelter.currentOccupancy) {
          setSelectedShelter(updatedSelectedShelter);
        }
      }
    });
    
    // Store unsubscribe function for cleanup
    occupancyUnsubscribeRef.current = unsubscribe;
    
    // Start real-time updates (every 30 seconds)
    occupancyService.startUpdates();
    
    // Cleanup on component unmount
    return () => {
      occupancyService.stopUpdates();
      if (occupancyUnsubscribeRef.current) {
        occupancyUnsubscribeRef.current();
      }
    };
  }, []); // Removed selectedShelter dependency to prevent continuous re-renders

  // Apply filters
  useEffect(() => {
    let filtered = [...shelters];
    
    // Apply food filter
    if (filterOptions.foodAvailable) {
      filtered = filtered.filter(shelter => shelter.hasFood);
    }
    
    // Apply space filter
    if (filterOptions.spaceAvailable) {
      filtered = filtered.filter(shelter => shelter.hasSpace);
    }
    
    // Apply occupancy level filter
    if (filterOptions.occupancyLevel !== 'all') {
      filtered = filtered.filter(shelter => {
        const occupancyPercentage = (shelter.currentOccupancy / shelter.capacity) * 100;
        
        switch (filterOptions.occupancyLevel) {
          case 'low':
            return occupancyPercentage < 25;
          case 'medium':
            return occupancyPercentage >= 25 && occupancyPercentage < 50;
          case 'high':
            return occupancyPercentage >= 50 && occupancyPercentage < 90;
          case 'full':
            return occupancyPercentage >= 90;
          default:
            return true;
        }
      });
    }
    
    setFilteredShelters(filtered);
  }, [filterOptions, shelters]);

  // Toggle filter for food availability
  const toggleFoodFilter = (checked: boolean) => {
    setFilterOptions(prev => ({ ...prev, foodAvailable: checked }));
  };

  // Toggle filter for space availability
  const toggleSpaceFilter = (checked: boolean) => {
    setFilterOptions(prev => ({ ...prev, spaceAvailable: checked }));
  };

  // Reset all filters
  const resetFilters = () => {
    setFilterOptions({
      foodAvailable: false,
      spaceAvailable: false,
      occupancyLevel: 'all'
    });
  };
  
  // Toggle occupancy level filter
  const setOccupancyLevelFilter = (level: 'all' | 'low' | 'medium' | 'high' | 'full') => {
    setFilterOptions(prev => ({ ...prev, occupancyLevel: level }));
  };

  // Handle selection of a shelter
  const handleSelectShelter = useCallback((shelter: Shelter) => {
    setSelectedShelter(prev => {
      if (!prev || prev.id !== shelter.id) {
        return shelter;
      }
      return prev;
    });
  }, []);

  // Update route information (distance and duration)
  const updateRouteInfo = useCallback((distance: string, duration: string) => {
    setRouteInfo(prev => {
      if (!prev || prev.distance !== distance || prev.duration !== duration) {
        return { distance, duration };
      }
      return prev;
    });
  }, []);

  // Generate URL for external navigation
  const getDirectionsUrl = () => {
    if (!selectedShelter || !userLocation) return '#';
    return `https://www.google.com/maps/dir/?api=1&origin=${userLocation[0]},${userLocation[1]}&destination=${selectedShelter.latitude},${selectedShelter.longitude}&travelmode=driving`;
  };

  // Toggle mobile filter panel
  const toggleMobileFilter = () => {
    setShowMobileFilter(prev => !prev);
  };

  return (
    <div className="flex flex-col min-h-screen bg-light text-dark">
      <Header toggleFilterBtn={toggleMobileFilter} />
      
      <div className="flex flex-col md:flex-row h-[calc(100vh-64px)]">
        <FilterPanel 
          filterOptions={filterOptions}
          toggleFoodFilter={toggleFoodFilter}
          toggleSpaceFilter={toggleSpaceFilter}
          setOccupancyLevelFilter={setOccupancyLevelFilter}
          resetFilters={resetFilters}
          selectedShelter={selectedShelter}
          routeInfo={routeInfo}
          getDirectionsUrl={getDirectionsUrl()}
          hasUserLocation={!!userLocation}
        />
        
        <div className="relative flex-1">
          <ShelterMap 
            shelters={filteredShelters}
            selectedShelter={selectedShelter}
            onSelectShelter={handleSelectShelter}
            userLocation={userLocation}
            updateRouteInfo={updateRouteInfo}
          />
          
          <button 
            onClick={getCurrentLocation}
            className="absolute bottom-6 right-6 map-control-button text-primary shadow-lg z-10"
            aria-label="Get current location"
            title="Get current location"
          >
            <i className="bx bx-current-location text-xl"></i>
          </button>
        </div>
      </div>
      
      <MobileFilterPanel 
        isVisible={showMobileFilter}
        filterOptions={filterOptions}
        toggleFoodFilter={toggleFoodFilter}
        toggleSpaceFilter={toggleSpaceFilter}
        setOccupancyLevelFilter={setOccupancyLevelFilter}
        resetFilters={resetFilters}
        selectedShelter={selectedShelter}
        getDirectionsUrl={getDirectionsUrl()}
        hasUserLocation={!!userLocation}
        toggleMobileFilter={toggleMobileFilter}
      />
    </div>
  );
}