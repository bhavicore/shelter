import { Shelter } from '@/types/shelter';

// Initial shelter data for Chennai locations
export const shelterData: Shelter[] = [
  {
    id: 11,
    name: "Chromepet Emergency Center",
    latitude: 12.9516,
    longitude: 80.1462,
    hasFood: true,
    hasSpace: true,
    capacity: 120,
    currentOccupancy: 20
  },
  {
    id: 1,
    name: "Marina Beach Shelter",
    latitude: 13.0500,
    longitude: 80.2824,
    hasFood: true,
    hasSpace: true,
    capacity: 200,
    currentOccupancy: 130
  },
  {
    id: 2,
    name: "Mylapore Relief Center",
    latitude: 13.0369,
    longitude: 80.2676,
    hasFood: true,
    hasSpace: false,
    capacity: 150,
    currentOccupancy: 150
  },
  {
    id: 3,
    name: "T. Nagar Community Shelter",
    latitude: 13.0418,
    longitude: 80.2341,
    hasFood: false,
    hasSpace: true,
    capacity: 120,
    currentOccupancy: 75
  },
  {
    id: 4,
    name: "Anna Nagar Relief Center",
    latitude: 13.0891,
    longitude: 80.2094,
    hasFood: true,
    hasSpace: true,
    capacity: 180,
    currentOccupancy: 95
  },
  {
    id: 5,
    name: "Adyar Flood Shelter",
    latitude: 13.0012,
    longitude: 80.2565,
    hasFood: true,
    hasSpace: true,
    capacity: 220,
    currentOccupancy: 160
  },
  {
    id: 6,
    name: "Velachery Safe House",
    latitude: 12.9814,
    longitude: 80.2180,
    hasFood: false,
    hasSpace: true,
    capacity: 140,
    currentOccupancy: 60
  },
  {
    id: 7,
    name: "Egmore Emergency Center",
    latitude: 13.0732,
    longitude: 80.2609,
    hasFood: true,
    hasSpace: false,
    capacity: 160,
    currentOccupancy: 160
  },
  {
    id: 8,
    name: "Guindy Evacuation Center",
    latitude: 13.0067,
    longitude: 80.2206,
    hasFood: true,
    hasSpace: true,
    capacity: 130,
    currentOccupancy: 25
  },
  {
    id: 9,
    name: "Perambur Community Hall",
    latitude: 13.1088,
    longitude: 80.2406,
    hasFood: false,
    hasSpace: true,
    capacity: 110,
    currentOccupancy: 65
  },
  {
    id: 10,
    name: "Tambaram Relief Center",
    latitude: 12.9249,
    longitude: 80.1000,
    hasFood: true,
    hasSpace: false,
    capacity: 175,
    currentOccupancy: 175
  }
];