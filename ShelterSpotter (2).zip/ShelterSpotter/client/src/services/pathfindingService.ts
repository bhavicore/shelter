import { Shelter } from '@/types/shelter';

// Types for our graph representation
interface Node {
  id: string;
  lat: number;
  lng: number;
}

interface Edge {
  from: string;
  to: string;
  weight: number;
}

interface Graph {
  nodes: Map<string, Node>;
  adjacencyList: Map<string, { node: string, weight: number }[]>;
}

// Helper function to calculate distance between two points (Haversine formula)
const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Radius of earth in km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2); 
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
  return R * c; // Distance in km
};

// Generate a grid of nodes between two points to simulate a road network
const generateGridNodes = (startLat: number, startLng: number, endLat: number, endLng: number, density: number = 5): Node[] => {
  const nodes: Node[] = [];
  const latMin = Math.min(startLat, endLat);
  const latMax = Math.max(startLat, endLat);
  const lngMin = Math.min(startLng, endLng);
  const lngMax = Math.max(startLng, endLng);

  // Calculate the step size based on the density
  const latStep = (latMax - latMin) / density;
  const lngStep = (lngMax - lngMin) / density;

  // Add start and end points
  nodes.push({ id: 'start', lat: startLat, lng: startLng });
  nodes.push({ id: 'end', lat: endLat, lng: endLng });

  // Generate grid nodes
  for (let i = 0; i <= density; i++) {
    for (let j = 0; j <= density; j++) {
      const lat = latMin + (i * latStep);
      const lng = lngMin + (j * lngStep);
      const id = `node_${i}_${j}`;

      // Skip if too close to start or end
      if (calculateDistance(lat, lng, startLat, startLng) < 0.1 || 
          calculateDistance(lat, lng, endLat, endLng) < 0.1) {
        continue;
      }

      nodes.push({ id, lat, lng });
    }
  }

  // Add some random obstacles/detours
  for (let i = 0; i < density; i++) {
    const lat = latMin + (Math.random() * (latMax - latMin));
    const lng = lngMin + (Math.random() * (lngMax - lngMin));
    const id = `obstacle_${i}`;
    nodes.push({ id, lat, lng });
  }

  return nodes;
};

// Create a graph from nodes by connecting neighbors
const createGraph = (nodes: Node[]): Graph => {
  const graph: Graph = {
    nodes: new Map(),
    adjacencyList: new Map()
  };

  // Add all nodes to the graph
  nodes.forEach(node => {
    graph.nodes.set(node.id, node);
    graph.adjacencyList.set(node.id, []);
  });

  // Connect nodes (create edges)
  nodes.forEach(node1 => {
    nodes.forEach(node2 => {
      if (node1.id !== node2.id) {
        const distance = calculateDistance(node1.lat, node1.lng, node2.lat, node2.lng);

        // Only connect if relatively close (to create a realistic network)
        // The threshold is higher for start and end nodes to ensure they're connected
        const threshold = (node1.id === 'start' || node1.id === 'end' || 
                          node2.id === 'start' || node2.id === 'end') ? 5 : 1.5;

        if (distance < threshold) {
          const adjacentNodes = graph.adjacencyList.get(node1.id) || [];
          adjacentNodes.push({ 
            node: node2.id, 
            weight: distance 
          });
          graph.adjacencyList.set(node1.id, adjacentNodes);
        }
      }
    });
  });

  return graph;
};

// DIJKSTRA'S ALGORITHM IMPLEMENTATION
export const findShortestPathDijkstra = (
  startLat: number, 
  startLng: number, 
  endLat: number, 
  endLng: number
): { path: [number, number][], distance: number, algorithm: string } => {
  console.log("Running Dijkstra's algorithm for pathfinding");

  // Generate nodes and create graph
  const nodes = generateGridNodes(startLat, startLng, endLat, endLng);
  const graph = createGraph(nodes);

  // Initialize algorithm data structures
  const distances = new Map<string, number>();
  const previous = new Map<string, string>();
  const unvisited = new Set<string>();

  // Initialize all distances as infinity and add all nodes to unvisited set
  graph.nodes.forEach((node, id) => {
    distances.set(id, id === 'start' ? 0 : Infinity);
    unvisited.add(id);
  });

  // Main Dijkstra algorithm loop
  while (unvisited.size > 0) {
    // Find the unvisited node with the smallest distance
    let currentNodeId: string | null = null;
    let smallestDistance = Infinity;

    unvisited.forEach(nodeId => {
      const distance = distances.get(nodeId) || Infinity;
      if (distance < smallestDistance) {
        smallestDistance = distance;
        currentNodeId = nodeId;
      }
    });

    // If we can't find any node or we've reached the end, break
    if (currentNodeId === null || currentNodeId === 'end' || smallestDistance === Infinity) {
      break;
    }

    // Remove current node from unvisited set
    unvisited.delete(currentNodeId);

    // Update distances to neighboring nodes
    const neighbors = graph.adjacencyList.get(currentNodeId) || [];
    neighbors.forEach(neighbor => {
      if (unvisited.has(neighbor.node)) {
        const newDistance = (distances.get(currentNodeId!) || 0) + neighbor.weight;
        const currentDistance = distances.get(neighbor.node) || Infinity;

        if (newDistance < currentDistance) {
          distances.set(neighbor.node, newDistance);
          previous.set(neighbor.node, currentNodeId!);
        }
      }
    });
  }

  // Reconstruct the path
  const path: [number, number][] = [];
  let current = 'end';

  if (previous.get('end') !== undefined || current === 'start') {
    while (current) {
      const node = graph.nodes.get(current);
      if (node) {
        path.unshift([node.lat, node.lng] as [number, number]);
      }

      const prev = previous.get(current);
      if (!prev || prev === current) break;
      current = prev;
    }
  }

  // If no path found, return direct path
  if (path.length < 2) {
    return {
      path: [[startLat, startLng], [endLat, endLng]],
      distance: calculateDistance(startLat, startLng, endLat, endLng),
      algorithm: "Dijkstra (Direct Path Fallback)"
    };
  }

  return {
    path,
    distance: distances.get('end') || calculateDistance(startLat, startLng, endLat, endLng),
    algorithm: "Dijkstra"
  };
};



// Cache for previously calculated routes
interface RouteCache {
  key: string;
  path: [number, number][];
  distance: number;
  algorithm: string;
  timestamp: number;
}

const routeCache: RouteCache[] = [];
const CACHE_TTL = 60 * 60 * 1000; // Cache time-to-live: 1 hour

// Disaster profile weights (example)
interface DisasterWeights {
  alpha: number;
  beta: number;
  gamma: number;
}

interface DisasterProfiles {
  [disasterType: string]: DisasterWeights;
}

const DISASTER_PROFILES: DisasterProfiles = {
  flood: { alpha: 1, beta: 2, gamma: 0.5 },
  earthquake: { alpha: 0.8, beta: 1.5, gamma: 0.7 },
  fire: { alpha: 1.2, beta: 2.5, gamma: 0.3 }
};

// Find nearest shelter using multiple algorithms and caching
export const findNearestShelter = (
  userLat: number,
  userLng: number,
  shelters: Shelter[],
  disasterType: string, // Added disaster type parameter
  algorithm: 'dijkstra' | 'dp' | 'backtracking' | 'auto' = 'auto'
): { 
  shelter: Shelter, 
  path: [number, number][], 
  distance: number, 
  duration: string,
  algorithm: string
} => {
  console.log(`Finding nearest shelter using ${algorithm} algorithm`);

  let nearestShelter: Shelter | null = null;
  let shortestDistance = Infinity;
  let bestPath: [number, number][] = [];
  let bestAlgorithm = '';

  // Get disaster weights based on type
  const weights = DISASTER_PROFILES[disasterType];

  // Calculate hazard-weighted costs for each shelter
  shelters.forEach(shelter => {
    const occupancyRatio = shelter.currentOccupancy / shelter.capacity;
    const hazardRisk = 0.2; // Base hazard risk, can be adjusted

    // Calculate weighted cost using the disaster profile
    const cost = weights.alpha * calculateDistance(userLat, userLng, shelter.latitude, shelter.longitude) +
                 weights.beta * Math.pow(occupancyRatio, 2) +
                 weights.gamma * hazardRisk;

    shelter.cost = cost;
  });

  // Sort by total weighted cost
  const sortedShelters = [...shelters].sort((a, b) => (a.cost || 0) - (b.cost || 0));


  // Second pass: detailed routing for potential shelters
  for (const shelter of sortedShelters) {
    // Generate cache key
    const cacheKey = `${userLat},${userLng}-${shelter.latitude},${shelter.longitude}-${algorithm}-${disasterType}`;

    // Check cache
    const cacheEntry = routeCache.find(entry => 
      entry.key === cacheKey && (Date.now() - entry.timestamp) < CACHE_TTL
    );

    if (cacheEntry) {
      console.log("Using cached route");
      if (cacheEntry.distance < shortestDistance) {
        shortestDistance = cacheEntry.distance;
        nearestShelter = shelter;
        bestPath = cacheEntry.path;
        bestAlgorithm = cacheEntry.algorithm;
      }
      continue;
    }

    let result;

    // Choose algorithm based on preference or 'auto'
    if (algorithm === 'dijkstra' || (algorithm === 'auto' && Math.random() < 0.33)) {
      result = findShortestPathDijkstra(
        userLat, userLng, shelter.latitude, shelter.longitude
      );
    } else if (algorithm === 'dp' || (algorithm === 'auto' && Math.random() < 0.5)) {
      result = findShortestPathDP(
        userLat, userLng, shelter.latitude, shelter.longitude
      );
    } else {
      result = findShortestPathBacktracking(
        userLat, userLng, shelter.latitude, shelter.longitude
      );
    }

    // Cache the result
    routeCache.push({
      key: cacheKey,
      path: result.path,
      distance: result.distance,
      algorithm: result.algorithm,
      timestamp: Date.now()
    });

    // Limit cache size
    if (routeCache.length > 50) {
      routeCache.shift(); // Remove oldest entry
    }

    if (result.distance < shortestDistance) {
      shortestDistance = result.distance;
      nearestShelter = shelter;
      bestPath = result.path;
      bestAlgorithm = result.algorithm;
    }
  }

  if (!nearestShelter) {
    // Fallback to first shelter if none found
    nearestShelter = sortedShelters[0];
    bestPath = [[userLat, userLng], [nearestShelter.latitude, nearestShelter.longitude]];
    shortestDistance = calculateDistance(
      userLat, userLng, nearestShelter.latitude, nearestShelter.longitude
    );
    bestAlgorithm = "Direct Fallback";
  }

  // Calculate approximate duration (avg speed 30 km/h)
  const duration = Math.round((shortestDistance / 30) * 60) + ' mins';

  return {
    shelter: nearestShelter,
    path: bestPath,
    distance: shortestDistance,
    duration,
    algorithm: bestAlgorithm
  };
};