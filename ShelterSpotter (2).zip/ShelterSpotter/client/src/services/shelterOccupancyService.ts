import { Shelter } from '@/types/shelter';

type OccupancyUpdateHandler = (shelters: Shelter[]) => void;

class ShelterOccupancyService {
  private shelters: Shelter[];
  private updateInterval: number | null = null;
  private listeners: OccupancyUpdateHandler[] = [];
  
  constructor(initialShelters: Shelter[]) {
    this.shelters = [...initialShelters];
  }
  
  // Start real-time updates
  startUpdates(intervalMs: number = 30000) { // Increased to 30 seconds
    if (this.updateInterval) return;
    
    this.updateInterval = window.setInterval(() => {
      this.simulateOccupancyChanges();
      this.notifyListeners();
    }, intervalMs);
  }
  
  // Stop real-time updates
  stopUpdates() {
    if (this.updateInterval) {
      window.clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
  }
  
  // Subscribe to occupancy updates
  subscribe(handler: OccupancyUpdateHandler) {
    this.listeners.push(handler);
    return () => this.unsubscribe(handler);
  }
  
  // Unsubscribe from updates
  unsubscribe(handler: OccupancyUpdateHandler) {
    this.listeners = this.listeners.filter(h => h !== handler);
  }
  
  // Get current shelters data
  getShelters() {
    return [...this.shelters];
  }
  
  // Private: Simulate random changes in occupancy
  private simulateOccupancyChanges() {
    this.shelters = this.shelters.map(shelter => {
      // Decide if this shelter will have a change (30% chance)
      if (Math.random() < 0.3) {
        // Determine if occupancy increases or decreases
        const change = Math.random() < 0.6 ? 1 : -1; // 60% chance of increase
        
        // Calculate new occupancy
        let newOccupancy = shelter.currentOccupancy + change * Math.floor(Math.random() * 5 + 1);
        
        // Ensure occupancy stays within valid range
        newOccupancy = Math.max(0, Math.min(shelter.capacity, newOccupancy));
        
        // Update hasSpace based on new occupancy
        const hasSpace = newOccupancy < shelter.capacity;
        
        return {
          ...shelter,
          currentOccupancy: newOccupancy,
          hasSpace
        };
      }
      
      return shelter;
    });
  }
  
  // Private: Notify all listeners of updates
  private notifyListeners() {
    const shelterData = this.getShelters();
    this.listeners.forEach(handler => handler(shelterData));
  }
}

// Create and export a singleton instance
let instance: ShelterOccupancyService | null = null;

export const getShelterOccupancyService = (initialShelters?: Shelter[]) => {
  if (!instance && initialShelters) {
    instance = new ShelterOccupancyService(initialShelters);
  }
  return instance as ShelterOccupancyService;
};