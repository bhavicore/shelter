import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Define global types for window objects
declare global {
  interface Window {
    ReactDOM: any;
    L: any;
  }
}

// Make ReactDOM available globally for InfoWindow component
import * as ReactDOM from "react-dom";
window.ReactDOM = ReactDOM;

// Render the application
console.log("Initializing application");

// Function to render the app
const renderApp = () => {
  console.log("Rendering app...");
  const rootElement = document.getElementById("root");
  if (rootElement) {
    console.log("Root element found, mounting app");
    createRoot(rootElement).render(<App />);
  } else {
    console.error("Root element not found");
  }
};

// Check if DOM is ready, then render the app
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    console.log("DOM content loaded, rendering app");
    renderApp();
  });
} else {
  console.log("DOM already loaded, rendering app");
  renderApp();
}
