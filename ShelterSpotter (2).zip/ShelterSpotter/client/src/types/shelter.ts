export interface Shelter {
  id: number;
  name: string;
  latitude: number;
  longitude: number;
  hasFood: boolean;
  hasSpace: boolean;
  capacity: number;
  currentOccupancy: number;
  cost?: number; // Total weighted cost for evacuation routing
  hazardRisk?: number; // Risk level for this shelter
}

// Occupancy level categories
export type OccupancyLevel = 'low' | 'medium' | 'high' | 'full';

/**
 * Get occupancy level category based on current occupancy percentage
 */
export const getOccupancyLevel = (shelter: Shelter): OccupancyLevel => {
  const percentage = (shelter.currentOccupancy / shelter.capacity) * 100;
  
  if (percentage < 25) return 'low';
  if (percentage < 50) return 'medium';
  if (percentage < 90) return 'high';
  return 'full';
};

/**
 * Get color for visualization based on occupancy level
 */
export const getOccupancyColor = (level: OccupancyLevel): string => {
  switch (level) {
    case 'low': return '#4CAF50'; // Green
    case 'medium': return '#FFC107'; // Yellow
    case 'high': return '#FF9800'; // Orange
    case 'full': return '#F44336'; // Red
    default: return '#757575'; // Grey
  }
};

/**
 * Get human-readable occupancy text
 */
export const getOccupancyText = (shelter: Shelter): string => {
  return `${shelter.currentOccupancy}/${shelter.capacity} spaces filled`;
};