interface HeaderProps {
  toggleFilterBtn: () => void;
}

export default function Header({ toggleFilterBtn }: HeaderProps) {
  return (
    <header className="bg-primary text-white shadow-md">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <i className="bx bxs-map text-2xl mr-2"></i>
          <h1 className="text-xl font-medium">Chennai Shelter Finder</h1>
        </div>
        <button 
          onClick={toggleFilterBtn}
          className="md:hidden btn-sm bg-white text-primary rounded-full font-medium shadow flex items-center"
        >
          <i className="bx bx-filter mr-1"></i> Filters
        </button>
      </div>
    </header>
  );
}
