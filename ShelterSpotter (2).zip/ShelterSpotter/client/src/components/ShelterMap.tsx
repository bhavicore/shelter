import { useEffect, useRef, useState } from 'react';
import { Shelter, getOccupancyLevel, getOccupancyColor } from '@/types/shelter';
import InfoWindow from './InfoWindow';
import { 
  findShortestPathDijkstra,
  findNearestShelter
} from '@/services/pathfindingService';

interface ShelterMapProps {
  shelters: Shelter[];
  selectedShelter: Shelter | null;
  onSelectShelter: (shelter: Shelter) => void;
  userLocation: [number, number] | null;
  updateRouteInfo: (distance: string, duration: string) => void;
}

export default function ShelterMap({ 
  shelters, 
  selectedShelter, 
  onSelectShelter,
  userLocation,
  updateRouteInfo
}: ShelterMapProps) {
  const mapRef = useRef<any>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const markersRef = useRef<any[]>([]);
  const userMarkerRef = useRef<any>(null);
  const routingControlRef = useRef<any>(null);
  const routePolylineRef = useRef<any>(null);
  const waypointMarkersRef = useRef<any[]>([]);
  const [leaflet, setLeaflet] = useState<any>(null);
  // Remove unused states

  // Get marker color based on shelter occupancy level
  const getMarkerColor = (shelter: Shelter) => {
    // Get occupancy level and corresponding color
    const level = getOccupancyLevel(shelter);
    return getOccupancyColor(level);
  };

  // Initialize leaflet map
  useEffect(() => {
    console.log("Checking for Leaflet library");

    // Define a function to check for Leaflet
    const checkForLeaflet = () => {
      if (window.L) {
        console.log("Leaflet found in window object");
        setLeaflet(window.L);
        return true;
      }
      console.log("Leaflet not found yet");
      return false;
    };

    // Try to get Leaflet immediately
    if (checkForLeaflet()) return;

    // If not available, set up a periodic check
    const checkLeaflet = setInterval(() => {
      if (checkForLeaflet()) {
        clearInterval(checkLeaflet);
      }
    }, 500);

    // Cleanup function
    return () => clearInterval(checkLeaflet);
  }, []);

  // Setup the map once Leaflet is loaded
  useEffect(() => {
    if (!leaflet || !mapContainerRef.current || mapRef.current) return;

    // Initialize map centered on Chennai
    const chennai: [number, number] = [13.0827, 80.2707];
    mapRef.current = leaflet.map(mapContainerRef.current).setView(chennai, 12);

    // Add tile layer
    leaflet.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(mapRef.current);

    // Initialize map with default controls only

    return () => {
      // Cleanup on unmount
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [leaflet]); //Removed routeAlgorithmInfo and algorithmType

  // Add shelter markers
  useEffect(() => {
    if (!leaflet || !mapRef.current) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];

    // Add markers for each shelter
    shelters.forEach(shelter => {
      // Create custom icon
      const markerColor = getMarkerColor(shelter);
      const customIcon = leaflet.divIcon({
        className: 'shelter-marker',
        html: `<div style="background-color: ${markerColor}; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; position: relative; box-shadow: 0 3px 6px rgba(0,0,0,0.3); border: 2px solid white;">
                <i class="bx bxs-home-alt-2 text-white text-lg"></i>
                <div style="position: absolute; bottom: -8px; left: 50%; transform: translateX(-50%); width: 0; height: 0; border-left: 8px solid transparent; border-right: 8px solid transparent; border-top: 8px solid ${markerColor};"></div>
               </div>`,
        iconSize: [32, 40],
        iconAnchor: [16, 40]
      });

      // Create marker
      const marker = leaflet.marker([shelter.latitude, shelter.longitude], {
        icon: customIcon,
        title: shelter.name
      }).addTo(mapRef.current);

      // Add popup
      const popupContent = document.createElement('div');
      popupContent.innerHTML = `<div class="shelter-popup"></div>`;

      const popup = leaflet.popup({
        offset: [0, -40],
        closeButton: false,
        className: 'shelter-popup-container'
      }).setContent(popupContent);

      marker.bindPopup(popup);

      marker.on('click', () => {
        onSelectShelter(shelter);
        marker.openPopup();

        // Render React component into popup
        const popupContainer = document.querySelector('.shelter-popup');
        if (popupContainer && window.ReactDOM) {
          window.ReactDOM.render(
            <InfoWindow 
              shelter={shelter} 
              onGetRoute={() => onSelectShelter(shelter)} 
            />,
            popupContainer
          );
        }
      });

      markersRef.current.push(marker);
    });

    return () => {
      // Cleanup on change
      markersRef.current.forEach(marker => marker.remove());
      markersRef.current = [];
    };
  }, [leaflet, shelters, onSelectShelter]);

  // User location marker
  useEffect(() => {
    if (!leaflet || !mapRef.current || !userLocation) return;

    // Remove existing user marker
    if (userMarkerRef.current) {
      userMarkerRef.current.remove();
      userMarkerRef.current = null;
    }

    // Create user marker
    const userIcon = leaflet.divIcon({
      className: 'user-location-marker',
      html: `<div style="background-color: #2196F3; width: 24px; height: 24px; border-radius: 50%; border: 2px solid white; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 5px rgba(0,0,0,0.3);">
              <div style="background-color: white; width: 8px; height: 8px; border-radius: 50%;"></div>
              <div style="position: absolute; width: 40px; height: 40px; border-radius: 50%; border: 2px solid #2196F3; opacity: 0.5; animation: pulse 2s infinite;"></div>
             </div>
             <style>
               @keyframes pulse {
                 0% { transform: scale(0.5); opacity: 0.8; }
                 70% { transform: scale(1.5); opacity: 0; }
                 100% { transform: scale(0.5); opacity: 0; }
               }
             </style>`,
      iconSize: [40, 40],
      iconAnchor: [20, 20]
    });

    userMarkerRef.current = leaflet.marker(userLocation, {
      icon: userIcon,
      zIndexOffset: 1000
    }).addTo(mapRef.current);

    // Center map on user location when first obtained
    mapRef.current.setView(userLocation, 12);

    return () => {
      if (userMarkerRef.current) {
        userMarkerRef.current.remove();
        userMarkerRef.current = null;
      }
    };
  }, [leaflet, userLocation]);

  // Calculate and display route
  useEffect(() => {
    if (!leaflet || !mapRef.current || !userLocation || !selectedShelter) {
      // Clean up existing route and markers when dependencies are missing
      if (routePolylineRef.current) {
        routePolylineRef.current.remove();
        routePolylineRef.current = null;
      }
      waypointMarkersRef.current.forEach(marker => marker.remove());
      waypointMarkersRef.current = [];
      return;
    }

    console.log("Calculating route...");

    // Remove existing route
    if (routePolylineRef.current) {
      routePolylineRef.current.remove();
      routePolylineRef.current = null;
    }

    // Clear existing waypoint markers
    waypointMarkersRef.current.forEach(marker => {
      if (marker) marker.remove();
    });
    waypointMarkersRef.current = [];

    // If user location or selected shelter are missing, remove any existing route
    if (!userLocation || !selectedShelter) {
      if (routingControlRef.current && mapRef.current) {
        mapRef.current.removeControl(routingControlRef.current);
        routingControlRef.current = null;
      }
      if (routePolylineRef.current) {
        routePolylineRef.current.remove();
        routePolylineRef.current = null;
      }
      return;
    }

    // Verify that userLocation and selectedShelter are valid
    if (!Array.isArray(userLocation) || userLocation.length !== 2 || 
        !selectedShelter || typeof selectedShelter.latitude !== 'number' || 
        typeof selectedShelter.longitude !== 'number') {
      return;
    }

    console.log("Attempting to add route from", userLocation, "to", [selectedShelter.latitude, selectedShelter.longitude]);


    // Draw route using Dijkstra's algorithm
    try {
      const routeResult = findShortestPathDijkstra(
        userLocation[0], userLocation[1],
        selectedShelter.latitude, selectedShelter.longitude
      );

      if (!routeResult || !routeResult.path || routeResult.path.length < 2) {
        console.warn("Invalid route result, using direct path");
        drawSimpleRoute(userLocation, [selectedShelter.latitude, selectedShelter.longitude]);
        return;
      }

      // Draw the route path
      const routePolyline = leaflet.polyline(
        routeResult.path,
        {
          color: '#2196F3',
          weight: 4,
          opacity: 0.8,
          dashArray: '5,10'
        }
      ).addTo(mapRef.current);

      routePolylineRef.current = routePolyline;

      // Update the route information
      updateRouteInfo(
        routeResult.distance.toFixed(1) + ' km',
        Math.round((routeResult.distance / 30) * 60) + ' mins'
      );

      // Add visual markers at waypoints
      if (routeResult.path.length > 2) {
        // First clear any previous waypoint markers 
        waypointMarkersRef.current.forEach(marker => marker.remove());
        waypointMarkersRef.current = [];

        // Add midpoint markers except for start and end
        for (let i = 1; i < routeResult.path.length - 1; i++) {
          const waypoint = routeResult.path[i];

          const waypointIcon = leaflet.divIcon({
            html: `<div style="width: 10px; height: 10px; background-color: #fff; border: 2px solid #2196F3; border-radius: 50%;"></div>`,
            className: 'waypoint-marker',
            iconSize: [10, 10],
            iconAnchor: [5, 5]
          });

          const marker = leaflet.marker(waypoint, {
            icon: waypointIcon,
            opacity: 0.7
          }).addTo(mapRef.current);

          // Save marker reference for later cleanup
          waypointMarkersRef.current.push(marker);
        }
      }

      // Fit bounds
      try {
        const bounds = routePolyline.getBounds();
        mapRef.current.fitBounds(bounds, { padding: [50, 50] });
      } catch (error) {
        console.error("Error fitting bounds:", error);
      }

    } catch (error) {
      console.error("Error using pathfinding algorithm:", error);
      // Fall back to simple route if algorithms fail
      drawSimpleRoute(userLocation, [selectedShelter.latitude, selectedShelter.longitude]);
    }
    return;

    function drawSimpleRoute(start: [number, number], end: [number, number]) {
      // We already checked that the map exists earlier in the effect
      if (!mapRef.current) return;

      try {
        // Create a simple straight line polyline
        const routePolyline = leaflet.polyline(
          [start, end],
          {
            color: '#2196F3',
            weight: 4,
            opacity: 0.7,
            dashArray: '10,10'
          }
        ).addTo(mapRef.current);

        // Store the reference for cleanup
        routePolylineRef.current = routePolyline;

        // Calculate approximate distance and duration
        const lat1 = start[0];
        const lon1 = start[1];
        const lat2 = end[0];
        const lon2 = end[1];

        // Simple distance calculation (haversine formula)
        const R = 6371; // Radius of earth in km
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = 
          Math.sin(dLat/2) * Math.sin(dLat/2) +
          Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
          Math.sin(dLon/2) * Math.sin(dLon/2); 
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
        const distance = R * c;

        // Assume average speed of 30 km/h
        const duration = (distance / 30) * 60;

        // Update route info
        updateRouteInfo(
          distance.toFixed(1) + ' km',
          Math.round(duration) + ' mins'
        );

        // Fit map to bounds if the polyline has bounds
        try {
          const bounds = routePolyline.getBounds();
          mapRef.current.fitBounds(bounds, { padding: [50, 50] });
        } catch (error) {
          console.error("Error fitting bounds:", error);
        }
      } catch (error) {
        console.error("Error drawing route:", error);
      }
    }

  }, [leaflet, userLocation, selectedShelter]);

  return (
    <div 
      ref={mapContainerRef} 
      className="w-full map-container bg-light"
    ></div>
  );
}