import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shelter, getOccupancyLevel, getOccupancyColor, getOccupancyText } from '@/types/shelter';

interface InfoWindowProps {
  shelter: Shelter;
  onGetRoute: () => void;
}

export default function InfoWindow({ shelter, onGetRoute }: InfoWindowProps) {
  // Get occupancy information
  const occupancyLevel = getOccupancyLevel(shelter);
  const occupancyColor = getOccupancyColor(occupancyLevel);
  const occupancyText = getOccupancyText(shelter);
  
  // Calculate percentage for progress bar
  const occupancyPercentage = (shelter.currentOccupancy / shelter.capacity) * 100;
  
  return (
    <div className="p-3 bg-white rounded-md shadow-md max-w-xs">
      <h3 className="text-lg font-bold mb-2">{shelter.name}</h3>
      
      <div className="space-y-2 mb-3">
        {/* Availability Badges */}
        <div className="flex flex-wrap gap-2">
          {shelter.hasFood && (
            <Badge variant="outline" className="bg-green-50 border-green-200 text-green-700">
              <i className="bx bx-food-menu mr-1"></i> Food Available
            </Badge>
          )}
          
          <Badge 
            variant="outline" 
            className={`${shelter.hasSpace 
              ? 'bg-green-50 border-green-200 text-green-700' 
              : 'bg-red-50 border-red-200 text-red-700'}`}
          >
            <i className={`bx ${shelter.hasSpace ? 'bx-check' : 'bx-x'} mr-1`}></i>
            {shelter.hasSpace ? 'Space Available' : 'No Space'}
          </Badge>
        </div>
        
        {/* Occupancy Information */}
        <div className="space-y-1">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Occupancy:</span>
            <span 
              className="text-sm font-medium" 
              style={{ color: occupancyColor }}
            >
              {occupancyText}
            </span>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-gray-200 rounded-full h-2.5 mb-2">
            <div 
              className="h-2.5 rounded-full" 
              style={{ 
                width: `${occupancyPercentage}%`,
                backgroundColor: occupancyColor
              }}
            ></div>
          </div>
          
          {/* Occupancy Level Badge */}
          <div className="flex justify-end">
            <Badge
              className="text-xs"
              style={{
                backgroundColor: `${occupancyColor}20`,
                color: occupancyColor,
                borderColor: occupancyColor
              }}
              variant="outline"
            >
              {occupancyLevel.charAt(0).toUpperCase() + occupancyLevel.slice(1)} Occupancy
            </Badge>
          </div>
        </div>
      </div>
      
      <Button 
        onClick={onGetRoute}
        className="w-full"
        variant="default"
      >
        <i className="bx bx-directions mr-1"></i> Get Directions
      </Button>
    </div>
  );
}