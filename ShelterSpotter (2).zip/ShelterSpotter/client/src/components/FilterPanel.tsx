import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Shelter, getOccupancyLevel, getOccupancyColor } from '@/types/shelter';

interface FilterPanelProps {
  filterOptions: {
    foodAvailable: boolean;
    spaceAvailable: boolean;
    occupancyLevel: 'all' | 'low' | 'medium' | 'high' | 'full';
  };
  toggleFoodFilter: (checked: boolean) => void;
  toggleSpaceFilter: (checked: boolean) => void;
  setOccupancyLevelFilter?: (level: 'all' | 'low' | 'medium' | 'high' | 'full') => void;
  resetFilters: () => void;
  selectedShelter: Shelter | null;
  routeInfo: {distance: string, duration: string} | null;
  getDirectionsUrl: string;
  hasUserLocation: boolean;
}

export default function FilterPanel({
  filterOptions,
  toggleFoodFilter,
  toggleSpaceFilter,
  setOccupancyLevelFilter,
  resetFilters,
  selectedShelter,
  routeInfo,
  getDirectionsUrl,
  hasUserLocation
}: FilterPanelProps) {
  return (
    <div className="w-full md:w-80 bg-background border-r border-border p-4 overflow-auto h-full shadow-md">
      <div className="space-y-4">
        <div>
          <h2 className="text-lg font-semibold mb-2">Filter Shelters</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor="food-filter" className="cursor-pointer">
                <div className="flex items-center">
                  <i className="bx bx-food-menu mr-2 text-primary"></i>
                  Food Available
                </div>
              </Label>
              <Switch 
                id="food-filter" 
                checked={filterOptions.foodAvailable}
                onCheckedChange={toggleFoodFilter}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="space-filter" className="cursor-pointer">
                <div className="flex items-center">
                  <i className="bx bx-building-house mr-2 text-primary"></i>
                  Space Available
                </div>
              </Label>
              <Switch 
                id="space-filter" 
                checked={filterOptions.spaceAvailable}
                onCheckedChange={toggleSpaceFilter}
              />
            </div>
            
            {/* Occupancy Level Filter */}
            <div className="space-y-2">
              <Label htmlFor="occupancy-filter">
                <div className="flex items-center">
                  <i className="bx bx-group mr-2 text-primary"></i>
                  Occupancy Level
                </div>
              </Label>
              <Select 
                value={filterOptions.occupancyLevel}
                onValueChange={(value) => setOccupancyLevelFilter?.(
                  value as 'all' | 'low' | 'medium' | 'high' | 'full'
                )}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Filter by occupancy" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Occupancy Levels</SelectItem>
                  <SelectItem value="low">
                    <div className="flex items-center">
                      <span className="h-2 w-2 rounded-full bg-green-500 mr-2"></span>
                      Low Occupancy (&lt; 25%)
                    </div>
                  </SelectItem>
                  <SelectItem value="medium">
                    <div className="flex items-center">
                      <span className="h-2 w-2 rounded-full bg-yellow-500 mr-2"></span>
                      Medium Occupancy (25% - 50%)
                    </div>
                  </SelectItem>
                  <SelectItem value="high">
                    <div className="flex items-center">
                      <span className="h-2 w-2 rounded-full bg-orange-500 mr-2"></span>
                      High Occupancy (50% - 90%)
                    </div>
                  </SelectItem>
                  <SelectItem value="full">
                    <div className="flex items-center">
                      <span className="h-2 w-2 rounded-full bg-red-500 mr-2"></span>
                      Full (&gt; 90%)
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Button 
              variant="outline" 
              className="w-full" 
              onClick={resetFilters}
            >
              <i className="bx bx-reset mr-1"></i> Reset Filters
            </Button>
          </div>
        </div>
        
        <Separator />
        
        {selectedShelter ? (
          <div>
            <h2 className="text-lg font-semibold mb-2">Selected Shelter</h2>
            <div className="bg-muted rounded-md p-3 space-y-3">
              <div>
                <h3 className="font-medium text-base">{selectedShelter.name}</h3>
                
                <div className="flex flex-wrap gap-2 mt-2">
                  {selectedShelter.hasFood && (
                    <Badge variant="outline" className="text-xs bg-green-50 border-green-200 text-green-700">
                      <i className="bx bx-food-menu mr-1"></i> Food
                    </Badge>
                  )}
                  
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${selectedShelter.hasSpace 
                      ? 'bg-green-50 border-green-200 text-green-700' 
                      : 'bg-red-50 border-red-200 text-red-700'}`}
                  >
                    <i className={`bx ${selectedShelter.hasSpace ? 'bx-check' : 'bx-x'} mr-1`}></i>
                    {selectedShelter.hasSpace ? 'Space Available' : 'No Space'}
                  </Badge>
                  
                  {/* Occupancy Badge */}
                  {(() => {
                    const level = getOccupancyLevel(selectedShelter);
                    const color = getOccupancyColor(level);
                    return (
                      <Badge
                        className="text-xs"
                        style={{
                          backgroundColor: `${color}20`,
                          color: color,
                          borderColor: color
                        }}
                        variant="outline"
                      >
                        <i className="bx bx-group mr-1"></i>
                        {selectedShelter.currentOccupancy}/{selectedShelter.capacity}
                      </Badge>
                    );
                  })()}
                </div>
              </div>
              
              {routeInfo && (
                <div className="text-sm">
                  <div className="flex items-center text-muted-foreground">
                    <i className="bx bx-map-pin mr-1"></i> 
                    Distance: <span className="font-medium ml-1">{routeInfo.distance}</span>
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <i className="bx bx-time mr-1"></i> 
                    Estimated Time: <span className="font-medium ml-1">{routeInfo.duration}</span>
                  </div>
                </div>
              )}
              
              <Button 
                className="w-full"
                disabled={!hasUserLocation}
                onClick={() => window.open(getDirectionsUrl, '_blank')}
              >
                <i className="bx bx-directions mr-1"></i> Get Directions
              </Button>
            </div>
          </div>
        ) : (
          <div className="bg-muted rounded-md p-3 text-center text-muted-foreground">
            <i className="bx bx-home text-2xl"></i>
            <p className="mt-1">Select a shelter to see details</p>
          </div>
        )}
        
        {!hasUserLocation && (
          <div className="bg-amber-50 border border-amber-200 text-amber-700 rounded-md p-3 text-sm">
            <i className="bx bx-error-circle mr-1"></i>
            Share your location to see route information and find the nearest shelter.
          </div>
        )}
      </div>
    </div>
  );
}